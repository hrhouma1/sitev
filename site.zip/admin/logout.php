﻿<?php
session_start() ; 
session_destroy() ;
echo "Vous êtes déconnecté(e) avec succès, <a href='/demo'>retour à l'accueil</a>";
?>